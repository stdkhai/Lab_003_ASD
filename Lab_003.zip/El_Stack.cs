﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab_003
{
    class El_Stack
    {
        public int _inf;// Інформаційне поле
        //конструктор для створення нового елементу
        public El_Stack(int inf)
        { this._inf = inf; }
    }
}
